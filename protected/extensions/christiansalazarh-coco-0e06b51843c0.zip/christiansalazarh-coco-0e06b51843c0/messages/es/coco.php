<?php
	return array(
		"Server error. Upload directory isn't writable."=>
			'El directorio especificado para almacenar los archivos no tiene permisos de escritura.',
		"No files were uploaded."=>
			'No se subio ningun archivo',
		"File is empty"=>
			'El archivo esta vacio',
		"File is too large"=>
			'El archivo es muy grande',
		"File has an invalid extension, it should be one of "=>
			'El archivo tiene una extension no admitida. Debe ser una de: ',
		"Could not save uploaded file. The upload was cancelled, or server error encountered"=>
			'No se pudo guardar el archivo. Este fue cancelado o el servidor encontro un error',
	);
?>
